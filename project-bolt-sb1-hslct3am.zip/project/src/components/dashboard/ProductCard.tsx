import React from 'react';
import { BarChart3, Percent, Zap } from 'lucide-react';
import { Product } from '../../types';
import Card, { CardContent, CardFooter } from '../ui/Card';
import Badge from '../ui/Badge';
import Button from '../ui/Button';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const profitMargin = Math.round(((product.currentPrice - product.cost) / product.currentPrice) * 100);
  const profitAmount = product.currentPrice - product.cost;
  
  const getBadgeVariant = (margin: number) => {
    if (margin >= 40) return 'success';
    if (margin >= 20) return 'default';
    return 'warning';
  };
  
  return (
    <Card hoverable className="h-full flex flex-col">
      <div className="relative h-48 mb-4 rounded-md overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2">
          <Badge variant={getBadgeVariant(profitMargin)}>
            <Percent className="w-3 h-3 mr-1" /> {profitMargin}% margin
          </Badge>
        </div>
      </div>
      
      <CardContent className="flex-grow">
        <h3 className="font-medium text-gray-900 mb-1">{product.name}</h3>
        <div className="flex items-baseline mb-2">
          <span className="text-lg font-semibold text-gray-900">₹{product.currentPrice}</span>
          <span className="ml-2 text-sm text-gray-500">Cost: ₹{product.cost}</span>
        </div>
        
        <div className="mt-2 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">Profit per item:</span>
            <span className="font-medium text-green-600">₹{profitAmount}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">In stock:</span>
            <span className="font-medium">{product.stock} units</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">Category:</span>
            <span className="font-medium">{product.category} / {product.subcategory}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="pt-4 mt-auto">
        <div className="flex space-x-2 w-full">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
          >
            <BarChart3 className="w-4 h-4 mr-1" />
            Analytics
          </Button>
          <Button 
            variant="primary" 
            size="sm" 
            className="flex-1"
            onClick={() => onSelect(product)}
          >
            <Zap className="w-4 h-4 mr-1" />
            Optimize
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;