import React, { useState, useEffect } from 'react';
import { Calculator, Edit2 } from 'lucide-react';
import Card, { CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import { Product, PricingFees } from '../../types';
import { calculateMeeshoFees, calculateShippingCost } from '../../utils/mockData';

interface ProfitCalculatorProps {
  product: Product;
  onPriceChange: (newPrice: number) => void;
}

const ProfitCalculator: React.FC<ProfitCalculatorProps> = ({ product, onPriceChange }) => {
  const [price, setPrice] = useState(product.currentPrice);
  const [isEditing, setIsEditing] = useState(false);
  const [fees, setFees] = useState<PricingFees>({
    meeshoCommission: 0,
    shippingCost: 0,
    packagingCost: 15,
    otherCosts: 10
  });
  
  useEffect(() => {
    setPrice(product.currentPrice);
    // Calculate fees based on current price
    setFees({
      meeshoCommission: calculateMeeshoFees(product.currentPrice),
      shippingCost: calculateShippingCost(product.category),
      packagingCost: 15,
      otherCosts: 10
    });
  }, [product]);
  
  useEffect(() => {
    // Recalculate Meesho commission when price changes
    setFees(prev => ({
      ...prev,
      meeshoCommission: calculateMeeshoFees(price)
    }));
  }, [price]);
  
  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPrice = parseInt(e.target.value);
    if (!isNaN(newPrice) && newPrice > 0) {
      setPrice(newPrice);
    }
  };
  
  const handleSave = () => {
    setIsEditing(false);
    onPriceChange(price);
  };
  
  // Calculate profit metrics
  const totalCosts = product.cost + fees.meeshoCommission + fees.shippingCost + fees.packagingCost + fees.otherCosts;
  const profit = price - totalCosts;
  const profitMargin = (profit / price) * 100;
  const roi = (profit / totalCosts) * 100;
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <Calculator className="w-5 h-5 mr-2 text-purple-600" />
          <CardTitle>Profit Calculator</CardTitle>
        </div>
        <CardDescription>
          Calculate your profit margin and ROI
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Selling Price</span>
            {isEditing ? (
              <div className="flex items-center">
                <span className="mr-2 text-gray-500">₹</span>
                <input
                  type="number"
                  value={price}
                  onChange={handlePriceChange}
                  className="w-24 px-2 py-1 border border-gray-300 rounded"
                  autoFocus
                />
              </div>
            ) : (
              <div className="flex items-center">
                <span className="text-lg font-semibold">₹{price}</span>
                <button 
                  onClick={() => setIsEditing(true)}
                  className="ml-2 text-purple-600 hover:text-purple-700"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
          
          <div className="border-t border-gray-200 pt-4">
            <h4 className="font-medium text-sm mb-3">Costs Breakdown</h4>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Product Cost</span>
                <span>₹{product.cost}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Meesho Commission</span>
                <span>₹{fees.meeshoCommission}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Shipping</span>
                <span>₹{fees.shippingCost}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Packaging</span>
                <span>₹{fees.packagingCost}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Other Costs</span>
                <span>₹{fees.otherCosts}</span>
              </div>
              <div className="flex justify-between font-medium pt-2 border-t border-gray-100">
                <span>Total Costs</span>
                <span>₹{totalCosts}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-purple-50 p-4 rounded-lg mt-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs text-gray-500 mb-1">Profit per Item</p>
                <p className={`text-lg font-semibold ${profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  ₹{profit.toFixed(0)}
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Profit Margin</p>
                <p className={`text-lg font-semibold ${profitMargin >= 20 ? 'text-green-600' : profitMargin >= 10 ? 'text-amber-600' : 'text-red-600'}`}>
                  {profitMargin.toFixed(1)}%
                </p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">ROI</p>
                <p className={`text-lg font-semibold ${roi >= 30 ? 'text-green-600' : roi >= 15 ? 'text-amber-600' : 'text-red-600'}`}>
                  {roi.toFixed(1)}%
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      
      {isEditing && (
        <CardFooter>
          <div className="flex space-x-2 w-full">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => {
                setPrice(product.currentPrice);
                setIsEditing(false);
              }}
            >
              Cancel
            </Button>
            <Button 
              variant="primary" 
              size="sm" 
              className="flex-1"
              onClick={handleSave}
            >
              Save Price
            </Button>
          </div>
        </CardFooter>
      )}
    </Card>
  );
};

export default ProfitCalculator;