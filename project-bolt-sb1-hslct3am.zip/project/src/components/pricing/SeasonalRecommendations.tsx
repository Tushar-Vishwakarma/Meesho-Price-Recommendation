import React from 'react';
import { Calendar, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { SeasonalTrend } from '../../types';
import Card, { CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card';

interface SeasonalRecommendationsProps {
  trends: SeasonalTrend[];
  currentPrice: number;
}

const SeasonalRecommendations: React.FC<SeasonalRecommendationsProps> = ({ 
  trends, 
  currentPrice 
}) => {
  // Find current season (in reality, this would use the current date)
  // For demo purposes, we'll just pick a season
  const currentSeason = trends[0];
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <Calendar className="w-5 h-5 mr-2 text-purple-600" />
          <CardTitle>Seasonal Pricing Recommendations</CardTitle>
        </div>
        <CardDescription>
          Optimize your prices based on seasonal trends
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="bg-purple-50 border border-purple-200 rounded-md p-3 mb-4">
          <p className="text-sm font-medium text-purple-800">
            Current Season: {currentSeason.season}
          </p>
          <p className="text-xs text-purple-700 mt-1">
            {currentSeason.notes}
          </p>
          {currentSeason.priceModifier !== 1 && (
            <p className="text-xs font-medium text-purple-800 mt-2">
              Recommended price: ₹{Math.round(currentPrice * currentSeason.priceModifier)} 
              ({currentSeason.priceModifier > 1 ? '+' : ''}{((currentSeason.priceModifier - 1) * 100).toFixed(0)}%)
            </p>
          )}
        </div>
        
        <h4 className="font-medium text-sm mb-3">Upcoming Seasons</h4>
        <div className="space-y-4">
          {trends.slice(1).map((trend, index) => {
            const recommendedPrice = Math.round(currentPrice * trend.priceModifier);
            const priceDifference = recommendedPrice - currentPrice;
            const percentChange = ((trend.priceModifier - 1) * 100).toFixed(0);
            
            return (
              <div key={index} className="border-b border-gray-100 pb-3 last:border-0 last:pb-0">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium text-sm">{trend.season}</span>
                  <div className="flex items-center">
                    {trend.demandTrend === 'high' ? (
                      <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                    ) : trend.demandTrend === 'low' ? (
                      <TrendingDown className="w-4 h-4 text-red-500 mr-1" />
                    ) : (
                      <Minus className="w-4 h-4 text-gray-500 mr-1" />
                    )}
                    <span className={`text-xs font-medium ${
                      trend.demandTrend === 'high' 
                        ? 'text-green-600' 
                        : trend.demandTrend === 'low' 
                          ? 'text-red-600' 
                          : 'text-gray-600'
                    }`}>
                      {trend.demandTrend.charAt(0).toUpperCase() + trend.demandTrend.slice(1)} Demand
                    </span>
                  </div>
                </div>
                
                <p className="text-xs text-gray-600 mb-2">{trend.notes}</p>
                
                <div className="flex items-center">
                  <span className="text-xs text-gray-600">Recommended price:</span>
                  <span className="ml-2 font-medium text-sm">₹{recommendedPrice}</span>
                  <span className={`ml-2 text-xs ${priceDifference >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {priceDifference >= 0 ? '+' : ''}{percentChange}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default SeasonalRecommendations;