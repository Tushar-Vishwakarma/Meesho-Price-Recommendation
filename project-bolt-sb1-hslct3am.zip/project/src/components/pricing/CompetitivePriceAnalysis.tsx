import React from 'react';
import { BarChart, Info } from 'lucide-react';
import { PriceAnalysis } from '../../types';
import Card, { CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card';

interface CompetitivePriceAnalysisProps {
  priceAnalysis: PriceAnalysis;
  currentPrice: number;
}

const CompetitivePriceAnalysis: React.FC<CompetitivePriceAnalysisProps> = ({ 
  priceAnalysis, 
  currentPrice 
}) => {
  const { minPrice, maxPrice, averagePrice, medianPrice, competitorPrices } = priceAnalysis;
  
  // Calculate the position of the current price on the range
  const rangeWidth = maxPrice - minPrice;
  const currentPricePosition = ((currentPrice - minPrice) / rangeWidth) * 100;
  
  // Calculate positions for average and median prices
  const averagePricePosition = ((averagePrice - minPrice) / rangeWidth) * 100;
  const medianPricePosition = ((medianPrice - minPrice) / rangeWidth) * 100;
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <BarChart className="w-5 h-5 mr-2 text-purple-600" />
          <CardTitle>Competitive Price Analysis</CardTitle>
        </div>
        <CardDescription>
          Compare your price with market rates
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="mb-8">
          <div className="flex justify-between text-sm mb-1">
            <span>Market Minimum: ₹{minPrice}</span>
            <span>Market Maximum: ₹{maxPrice}</span>
          </div>
          
          {/* Price range visualization */}
          <div className="relative h-8 bg-gray-100 rounded-full mb-4">
            <div className="absolute inset-y-0 left-0 bg-purple-100 rounded-full" style={{ width: '100%' }}></div>
            
            {/* Markers for average and median prices */}
            <div 
              className="absolute inset-y-0 w-1 bg-purple-400" 
              style={{ left: `${averagePricePosition}%` }}
              title={`Average: ₹${averagePrice}`}
            ></div>
            <div 
              className="absolute inset-y-0 w-1 bg-teal-400" 
              style={{ left: `${medianPricePosition}%` }}
              title={`Median: ₹${medianPrice}`}
            ></div>
            
            {/* Current price marker */}
            <div className="absolute -top-6 transform -translate-x-1/2" style={{ left: `${currentPricePosition}%` }}>
              <div className="flex flex-col items-center">
                <span className="px-2 py-1 bg-purple-600 text-white text-xs rounded">
                  Your price: ₹{currentPrice}
                </span>
                <div className="w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-purple-600"></div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between text-sm mb-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-purple-400 rounded-full mr-1"></div>
              <span>Average: ₹{averagePrice}</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-teal-400 rounded-full mr-1"></div>
              <span>Median: ₹{medianPrice}</span>
            </div>
          </div>
          
          <div className="flex items-center text-xs text-gray-500 mb-4">
            <Info className="w-4 h-4 mr-1" />
            <span>
              Your price is {currentPrice < averagePrice ? 'below' : 'above'} the market average by ₹
              {Math.abs(currentPrice - averagePrice)}.
            </span>
          </div>
        </div>
        
        <h4 className="font-medium text-sm mb-2">Competitor Prices</h4>
        <div className="space-y-3">
          {competitorPrices.map((competitor, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className="text-sm">{competitor.storeName}</span>
              <div className="flex items-center">
                <span className="text-sm font-medium">₹{competitor.price}</span>
                <span className={`ml-2 text-xs ${competitor.price < currentPrice ? 'text-red-500' : 'text-green-500'}`}>
                  {competitor.price < currentPrice 
                    ? `(₹${currentPrice - competitor.price} lower)` 
                    : `(₹${competitor.price - currentPrice} higher)`}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CompetitivePriceAnalysis;