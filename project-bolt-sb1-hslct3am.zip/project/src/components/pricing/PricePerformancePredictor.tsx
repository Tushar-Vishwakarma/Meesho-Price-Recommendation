import React from 'react';
import { TrendingUp, AlertCircle } from 'lucide-react';
import { PricePerformance } from '../../types';
import Card, { CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card';

interface PricePerformancePredictorProps {
  performances: PricePerformance[];
  currentPrice: number;
}

const PricePerformancePredictor: React.FC<PricePerformancePredictorProps> = ({ 
  performances,
  currentPrice
}) => {
  // Find optimal price point for maximum profit
  const maxProfitPerformance = [...performances].sort((a, b) => b.estimatedProfit - a.estimatedProfit)[0];
  
  // Find current price performance
  const currentPerformance = performances.find(p => p.price === currentPrice) || performances[0];
  
  // Calculate potential profit increase
  const potentialIncrease = maxProfitPerformance.estimatedProfit - currentPerformance.estimatedProfit;
  const increasePercentage = (potentialIncrease / currentPerformance.estimatedProfit) * 100;
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center">
          <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
          <CardTitle>Price Performance Predictor</CardTitle>
        </div>
        <CardDescription>
          Estimated sales and profit at different price points
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {potentialIncrease > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-md p-3 mb-4 flex items-start">
            <AlertCircle className="w-5 h-5 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-amber-800">Optimization opportunity</p>
              <p className="text-xs text-amber-700 mt-1">
                Changing your price to ₹{maxProfitPerformance.price} could increase your profit by approximately 
                <span className="font-semibold"> ₹{potentialIncrease.toFixed(0)}</span> ({increasePercentage.toFixed(0)}%) per batch of 100 units.
              </p>
            </div>
          </div>
        )}
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-3 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Price Point
                </th>
                <th className="px-3 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Est. Sales
                </th>
                <th className="px-3 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Est. Revenue
                </th>
                <th className="px-3 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Est. Profit
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {performances.map((performance, index) => {
                const isOptimal = performance.price === maxProfitPerformance.price;
                const isCurrent = performance.price === currentPrice;
                
                return (
                  <tr 
                    key={index} 
                    className={`${isOptimal ? 'bg-green-50' : isCurrent ? 'bg-purple-50' : ''}`}
                  >
                    <td className="px-3 py-3 whitespace-nowrap">
                      <div className="flex items-center">
                        <span className={`font-medium ${isOptimal ? 'text-green-700' : isCurrent ? 'text-purple-700' : ''}`}>
                          ₹{performance.price}
                        </span>
                        {isOptimal && (
                          <span className="ml-2 px-2 py-0.5 text-xs bg-green-100 text-green-800 rounded-full">
                            Best
                          </span>
                        )}
                        {isCurrent && !isOptimal && (
                          <span className="ml-2 px-2 py-0.5 text-xs bg-purple-100 text-purple-800 rounded-full">
                            Current
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap text-sm">
                      {performance.estimatedSales} units
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap text-sm">
                      ₹{performance.estimatedRevenue.toLocaleString()}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap text-sm font-medium">
                      <span className={isOptimal ? 'text-green-600' : ''}>
                        ₹{performance.estimatedProfit.toLocaleString()}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 text-xs text-gray-500 flex items-start">
          <AlertCircle className="w-4 h-4 mr-1 flex-shrink-0 mt-0.5" />
          <p>
            This prediction is based on estimated price elasticity and historical sales data. 
            Actual performance may vary based on market conditions, seasonality, and competition.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default PricePerformancePredictor;