import React, { useState } from 'react';
import Dashboard from './pages/Dashboard';
import ProductOptimizer from './pages/ProductOptimizer';
import { Product } from './types';

function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  return (
    <div className="min-h-screen bg-gray-50">
      {selectedProduct ? (
        <ProductOptimizer 
          product={selectedProduct}
          onBack={() => setSelectedProduct(null)}
        />
      ) : (
        <Dashboard onSelectProduct={setSelectedProduct} />
      )}
    </div>
  );
}

export default App;