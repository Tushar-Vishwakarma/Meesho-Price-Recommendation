import { Product, PriceAnalysis, PricePerformance, SeasonalTrend } from '../types';

export const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Floral Print Maxi Dress',
    category: 'Women',
    subcategory: 'Dresses',
    cost: 350,
    currentPrice: 699,
    stock: 45,
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '2',
    name: 'Men\'s Casual Shirt',
    category: 'Men',
    subcategory: 'Shirts',
    cost: 250,
    currentPrice: 499,
    stock: 30,
    image: 'https://images.pexels.com/photos/297933/pexels-photo-297933.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '3',
    name: 'Kids Party Wear',
    category: 'Kids',
    subcategory: 'Party Wear',
    cost: 300,
    currentPrice: 599,
    stock: 20,
    image: 'https://images.pexels.com/photos/5691392/pexels-photo-5691392.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '4',
    name: 'Women\'s Handbag',
    category: 'Accessories',
    subcategory: 'Bags',
    cost: 200,
    currentPrice: 450,
    stock: 25,
    image: 'https://images.pexels.com/photos/5705506/pexels-photo-5705506.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];

export const getMockPriceAnalysis = (productId: string): PriceAnalysis => {
  const product = mockProducts.find(p => p.id === productId);
  const currentPrice = product?.currentPrice || 500;
  
  // Generate random but realistic pricing data
  const minPrice = Math.round(currentPrice * 0.8);
  const maxPrice = Math.round(currentPrice * 1.3);
  const averagePrice = Math.round((minPrice + maxPrice) / 2);
  const medianPrice = Math.round(averagePrice * 0.95);
  
  // Generate mock competitor prices
  const competitorPrices = [
    { storeName: 'Fashion Hub', price: Math.round(currentPrice * 0.85) },
    { storeName: 'Trendy Store', price: Math.round(currentPrice * 1.1) },
    { storeName: 'Style Galaxy', price: Math.round(currentPrice * 0.95) },
    { storeName: 'Urban Closet', price: Math.round(currentPrice * 1.05) },
    { storeName: 'Fashion Fiesta', price: Math.round(currentPrice * 1.15) }
  ];
  
  return {
    minPrice,
    maxPrice,
    averagePrice,
    medianPrice,
    competitorPrices
  };
};

export const getMockPricePerformance = (
  productId: string, 
  productCost: number
): PricePerformance[] => {
  const product = mockProducts.find(p => p.id === productId);
  const currentPrice = product?.currentPrice || 500;
  
  // Generate price points around the current price
  const pricePoints = [
    Math.round(currentPrice * 0.7),
    Math.round(currentPrice * 0.8),
    Math.round(currentPrice * 0.9),
    currentPrice,
    Math.round(currentPrice * 1.1),
    Math.round(currentPrice * 1.2),
    Math.round(currentPrice * 1.3)
  ];
  
  // Generate sales estimates based on price elasticity
  return pricePoints.map(price => {
    // Simple price elasticity model: higher price = lower sales
    const elasticityFactor = Math.pow(currentPrice / price, 2.5);
    const baseSales = 100; // Base sales at current price
    const estimatedSales = Math.round(baseSales * elasticityFactor);
    const estimatedRevenue = price * estimatedSales;
    const estimatedProfit = (price - productCost) * estimatedSales;
    
    return {
      price,
      estimatedSales,
      estimatedRevenue,
      estimatedProfit
    };
  });
};

export const getMockSeasonalTrends = (category: string): SeasonalTrend[] => {
  // Base seasonal trends that apply to most categories
  const trends: SeasonalTrend[] = [
    {
      season: 'Summer (Apr-Jun)',
      priceModifier: 1.1,
      demandTrend: 'high',
      notes: 'Increased demand for lightweight items'
    },
    {
      season: 'Monsoon (Jul-Sep)',
      priceModifier: 0.9,
      demandTrend: 'medium',
      notes: 'Focus on weather-appropriate merchandise'
    },
    {
      season: 'Diwali (Oct-Nov)',
      priceModifier: 1.2,
      demandTrend: 'high',
      notes: 'Festival season drives higher purchases'
    },
    {
      season: 'Winter (Dec-Feb)',
      priceModifier: 1.05,
      demandTrend: 'medium',
      notes: 'Seasonal items see increased demand'
    },
    {
      season: 'Spring (Mar-Apr)',
      priceModifier: 1.0,
      demandTrend: 'medium',
      notes: 'Transition period with moderate demand'
    }
  ];
  
  // Adjust notes based on category
  if (category === 'Women') {
    trends[0].notes = 'High demand for summer dresses and light fabrics';
    trends[2].notes = 'Festival wear and ethnic collections see peak demand';
  } else if (category === 'Men') {
    trends[0].notes = 'Increased demand for t-shirts and casual wear';
    trends[2].notes = 'Formal and ethnic wear see significant boost';
  } else if (category === 'Kids') {
    trends[0].notes = 'Back-to-school season drives purchases';
    trends[2].notes = 'Festival and party wear see high demand';
  }
  
  return trends;
};

export const calculateMeeshoFees = (sellingPrice: number): number => {
  // Mock calculation - typically Meesho takes around 15-20% commission
  const commission = sellingPrice * 0.18;
  return Math.round(commission);
};

export const calculateShippingCost = (category: string): number => {
  // Mock shipping cost based on category
  const baseCost = 70;
  
  if (category === 'Accessories') return baseCost - 20;
  if (category === 'Kids') return baseCost - 10;
  
  return baseCost;
};