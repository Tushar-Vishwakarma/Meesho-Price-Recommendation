import React, { useState, useEffect } from 'react';
import { ArrowLeft, RefreshCcw } from 'lucide-react';
import Button from '../components/ui/Button';
import CompetitivePriceAnalysis from '../components/pricing/CompetitivePriceAnalysis';
import ProfitCalculator from '../components/pricing/ProfitCalculator';
import PricePerformancePredictor from '../components/pricing/PricePerformancePredictor';
import SeasonalRecommendations from '../components/pricing/SeasonalRecommendations';
import { Product, PriceAnalysis, PricePerformance, SeasonalTrend } from '../types';
import { 
  getMockPriceAnalysis, 
  getMockPricePerformance, 
  getMockSeasonalTrends 
} from '../utils/mockData';

interface ProductOptimizerProps {
  product: Product;
  onBack: () => void;
}

const ProductOptimizer: React.FC<ProductOptimizerProps> = ({ product, onBack }) => {
  const [updatedProduct, setUpdatedProduct] = useState<Product>(product);
  const [priceAnalysis, setPriceAnalysis] = useState<PriceAnalysis | null>(null);
  const [pricePerformances, setPricePerformances] = useState<PricePerformance[]>([]);
  const [seasonalTrends, setSeasonalTrends] = useState<SeasonalTrend[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate API loading delay
    setLoading(true);
    
    // Fetch mock data
    setTimeout(() => {
      const analysis = getMockPriceAnalysis(product.id);
      const performances = getMockPricePerformance(product.id, product.cost);
      const trends = getMockSeasonalTrends(product.category);
      
      setPriceAnalysis(analysis);
      setPricePerformances(performances);
      setSeasonalTrends(trends);
      setLoading(false);
    }, 800);
  }, [product]);
  
  const handlePriceChange = (newPrice: number) => {
    setUpdatedProduct(prev => ({
      ...prev,
      currentPrice: newPrice
    }));
    
    // Update performances based on new price
    setPricePerformances(getMockPricePerformance(product.id, product.cost));
  };
  
  const refreshData = () => {
    setLoading(true);
    
    // Simulate API request
    setTimeout(() => {
      const analysis = getMockPriceAnalysis(product.id);
      const performances = getMockPricePerformance(product.id, product.cost);
      const trends = getMockSeasonalTrends(product.category);
      
      setPriceAnalysis(analysis);
      setPricePerformances(performances);
      setSeasonalTrends(trends);
      setLoading(false);
    }, 800);
  };
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse space-y-6">
            <div className="h-10 bg-gray-200 rounded w-1/4"></div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="h-80 bg-gray-200 rounded"></div>
              <div className="h-80 bg-gray-200 rounded"></div>
              <div className="h-80 bg-gray-200 rounded"></div>
              <div className="h-80 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center">
            <Button 
              variant="outline" 
              size="sm"
              onClick={onBack}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back to Products
            </Button>
            
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{updatedProduct.name}</h1>
              <p className="text-sm text-gray-500">
                {updatedProduct.category} / {updatedProduct.subcategory}
              </p>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={refreshData}
          >
            <RefreshCcw className="w-4 h-4 mr-1" />
            Refresh Data
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {priceAnalysis && (
            <CompetitivePriceAnalysis 
              priceAnalysis={priceAnalysis}
              currentPrice={updatedProduct.currentPrice}
            />
          )}
          
          <ProfitCalculator 
            product={updatedProduct}
            onPriceChange={handlePriceChange}
          />
          
          {pricePerformances.length > 0 && (
            <PricePerformancePredictor 
              performances={pricePerformances}
              currentPrice={updatedProduct.currentPrice}
            />
          )}
          
          {seasonalTrends.length > 0 && (
            <SeasonalRecommendations 
              trends={seasonalTrends}
              currentPrice={updatedProduct.currentPrice}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductOptimizer;