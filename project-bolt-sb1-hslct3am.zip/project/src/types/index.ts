export interface Product {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  cost: number;
  currentPrice: number;
  stock: number;
  image: string;
}

export interface CompetitorPrice {
  storeName: string;
  price: number;
}

export interface PriceAnalysis {
  minPrice: number;
  maxPrice: number;
  averagePrice: number;
  medianPrice: number;
  competitorPrices: CompetitorPrice[];
}

export interface PricePerformance {
  price: number;
  estimatedSales: number;
  estimatedRevenue: number;
  estimatedProfit: number;
}

export interface SeasonalTrend {
  season: string;
  priceModifier: number;
  demandTrend: 'high' | 'medium' | 'low';
  notes: string;
}

export interface PricingFees {
  meeshoCommission: number;
  shippingCost: number;
  packagingCost: number;
  otherCosts: number;
}